-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : Dim 26 mars 2023 à 20:56
-- Version du serveur :  5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `study_class`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(10) NOT NULL AUTO_INCREMENT,
  `nom_admin` varchar(50) CHARACTER SET utf8 NOT NULL,
  `prénom_admin` varchar(50) CHARACTER SET utf8 NOT NULL,
  `email_admin` varchar(100) CHARACTER SET utf8 NOT NULL,
  `pass_admin` varchar(100) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `nom_admin`, `prénom_admin`, `email_admin`, `pass_admin`) VALUES
(2, 'soulemana', 'rumie', 'rumie@rumie.com', '$2y$10$Z4tgFu/awGW.huSqEuUlVe2goeoKiTlZng4H4OVlQ0wNSq.wkuZmC'),
(6, 'Leproux', 'Philippe', 'philippe.leproux@unilim.fr', '$2y$10$OM2ZAXv4mB8.jqXSgLuM.uN41LeeLwEL24B/9GpNp.xtfqmrDPuv.');

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

DROP TABLE IF EXISTS `etudiants`;
CREATE TABLE IF NOT EXISTS `etudiants` (
  `Id_Etudiant` int(10) NOT NULL AUTO_INCREMENT,
  `Etudiant` varchar(100) NOT NULL,
  `Utilisateur` varchar(100) NOT NULL,
  `Pass` varchar(50) NOT NULL,
  PRIMARY KEY (`Id_Etudiant`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`Id_Etudiant`, `Etudiant`, `Utilisateur`, `Pass`) VALUES
(1, 'Janka Neumanova (E)', 'janka@gmail.com', 'd7382144c9d52cbcafb0a5c46285669cba5c152b'),
(2, 'Hamza', 'hamza@gmail.com', 'ef3d7bfb0f2858843c0bc555ce4b34f2fa71038e'),
(3, 'Rumie', 'rumie@gmail.com', '5759823d4c5e39b1a008a661634968cf2b02a9a8');

-- --------------------------------------------------------

--
-- Structure de la table `evaluations_forms`
--

DROP TABLE IF EXISTS `evaluations_forms`;
CREATE TABLE IF NOT EXISTS `evaluations_forms` (
  `Id_Form` int(10) NOT NULL AUTO_INCREMENT,
  `Id_Formation` int(10) NOT NULL,
  `Id_Niveau` int(10) NOT NULL,
  `Version` double NOT NULL,
  `Coefficient` double NOT NULL,
  PRIMARY KEY (`Id_Form`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `evaluations_forms`
--

INSERT INTO `evaluations_forms` (`Id_Form`, `Id_Formation`, `Id_Niveau`, `Version`, `Coefficient`) VALUES
(1, 1, 1, 1, 2),
(2, 1, 2, 1, 1),
(3, 1, 3, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `evaluations_questions`
--

DROP TABLE IF EXISTS `evaluations_questions`;
CREATE TABLE IF NOT EXISTS `evaluations_questions` (
  `Id_Question` int(10) NOT NULL AUTO_INCREMENT,
  `Id_Form` int(10) NOT NULL,
  `Question` varchar(150) NOT NULL,
  PRIMARY KEY (`Id_Question`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `evaluations_questions`
--

INSERT INTO `evaluations_questions` (`Id_Question`, `Id_Form`, `Question`) VALUES
(1, 1, 'A quoi sert une variable ?'),
(2, 1, 'En PHP, un tableau se matérialise par :'),
(3, 1, 'Quel type de boucle ... ?'),
(4, 2, 'Quel type de cryptage peut-être utilisé pour un mot de passe'),
(5, 2, 'Une classe peut contenir plusieurs fonctions'),
(6, 2, 'Quel terme utiliser pour qu\'une classe hérite des propriété d\'une autre ?'),
(7, 3, 'Un autoloader permet :'),
(8, 3, 'Une fonction closure, peut être :');

-- --------------------------------------------------------

--
-- Structure de la table `evaluations_reponses`
--

DROP TABLE IF EXISTS `evaluations_reponses`;
CREATE TABLE IF NOT EXISTS `evaluations_reponses` (
  `Id_Reponse` int(10) NOT NULL AUTO_INCREMENT,
  `Id_Question` int(10) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Reponse` varchar(150) NOT NULL,
  `Points` double NOT NULL,
  PRIMARY KEY (`Id_Reponse`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `evaluations_reponses`
--

INSERT INTO `evaluations_reponses` (`Id_Reponse`, `Id_Question`, `Type`, `Reponse`, `Points`) VALUES
(1, 1, 'checkbox', 'Stocker une information', 1),
(2, 1, 'checkbox', 'Générer une réponse aléatoire', -1),
(3, 2, 'radio', 'Un array', 1),
(4, 2, 'radio', 'Une balise table', 0),
(5, 3, 'radio', 'Une boucle for', 0),
(6, 3, 'radio', 'Une boucle while', 1),
(7, 4, 'checkbox', 'sha1', 1),
(8, 4, 'checkbox', 'base64', 0),
(9, 4, 'checkbox', 'md5', 1),
(10, 5, 'radio', 'Vrai', 1),
(11, 5, 'radio', 'Faux', 0),
(12, 6, 'text', 'extends', 2),
(13, 7, 'radio', 'De regrouper toutes ses classes dans un fichier', 0),
(14, 7, 'radio', 'De gérer ses classes dans plusieurs fichiers', 1),
(15, 8, 'checkbox', 'Private', 1),
(16, 8, 'checkbox', 'Public', 1),
(17, 8, 'checkbox', 'Anonyme', 1);

-- --------------------------------------------------------

--
-- Structure de la table `evaluations_scores`
--

DROP TABLE IF EXISTS `evaluations_scores`;
CREATE TABLE IF NOT EXISTS `evaluations_scores` (
  `Id_Score` int(10) NOT NULL AUTO_INCREMENT,
  `Id_Form` int(10) NOT NULL,
  `Coefficient` double NOT NULL,
  `Id_Etudiant` int(10) NOT NULL,
  `Score` double NOT NULL,
  `Date_MAJ` datetime NOT NULL,
  PRIMARY KEY (`Id_Score`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `formateurs`
--

DROP TABLE IF EXISTS `formateurs`;
CREATE TABLE IF NOT EXISTS `formateurs` (
  `Id_Formateur` int(10) NOT NULL AUTO_INCREMENT,
  `Active` int(1) NOT NULL,
  `Formateur` varchar(100) NOT NULL,
  `Public_Email` varchar(100) NOT NULL,
  `Photo` varchar(100) NOT NULL,
  `Presentation` mediumtext NOT NULL,
  `Portfolio` varchar(150) NOT NULL,
  `User` varchar(100) NOT NULL,
  `Pass` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_Formateur`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formateurs`
--

INSERT INTO `formateurs` (`Id_Formateur`, `Active`, `Formateur`, `Public_Email`, `Photo`, `Presentation`, `Portfolio`, `User`, `Pass`) VALUES
(1, 1, 'Janka Neumanova', 'janka@gmail.com', '/assets/images/formateurs/janka-neumanova.jpg', '<p>Mon but est la transmission de l\'expertise, mon savoir et mes connaissances dans le domaine du web.</p>', 'https://www.jannistyle.fr', 'Janka', 'd7382144c9d52cbcafb0a5c46285669cba5c152b'),
(2, 1, 'Hamza Takkarouht', 'hamza@gmail.com', '/assets/images/formateurs/hamza-takkarouht.jpg', '<p>Mon but est la transmission de l\'expertise, mon savoir et mes connaissances dans le domaine du web.</p>', 'https://hamza-takarrouht.website/', 'Hamza', 'ef3d7bfb0f2858843c0bc555ce4b34f2fa71038e'),
(3, 1, 'Rumie Soulemana', 'rumie@gmail.com', '/assets/images/formateurs/rumie-soulemana.jpg', '<p>Mon but est la transmission de l\'expertise, mon savoir et mes connaissances dans le domaine du web.</p>', 'https://rumiesoulemana.compteweb.com/', 'Rumie', '5759823d4c5e39b1a008a661634968cf2b02a9a8');

-- --------------------------------------------------------

--
-- Structure de la table `formations`
--

DROP TABLE IF EXISTS `formations`;
CREATE TABLE IF NOT EXISTS `formations` (
  `Id_Formation` int(10) NOT NULL AUTO_INCREMENT,
  `Active` int(1) NOT NULL,
  `Formation` varchar(50) NOT NULL,
  `SEO` varchar(150) DEFAULT NULL,
  `Titre` varchar(150) NOT NULL,
  `Synthese` mediumtext NOT NULL,
  `Descriptif` mediumtext NOT NULL,
  `Duration` varchar(10) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `Id_Formateur` int(10) NOT NULL,
  PRIMARY KEY (`Id_Formation`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formations`
--

INSERT INTO `formations` (`Id_Formation`, `Active`, `Formation`, `SEO`, `Titre`, `Synthese`, `Descriptif`, `Duration`, `img`, `Id_Formateur`) VALUES
(1, 1, 'PHP', 'php', 'Langage de programmation PHP', '<p>PHP est un langage de programmation côté serveur, utilisé pour créer des sites web dynamiques.</p>\r\n<p>Il permet de générer des pages web dynamiques, de gérer des formulaires, d\'interagir avec des bases de données, de créer des sessions et bien plus encore.</p>\r\n<p>PHP est largement utilisé dans le développement web, en particulier avec le système de gestion de contenu WordPress.</p>\r\n<p>Le code PHP est exécuté sur le serveur, avant d\'être envoyé au navigateur de l\'utilisateur, ce qui signifie que le code source n\'est pas visible par les visiteurs du site web.</p>', '<p class=\"card-text\">Dans ce cours nous apprendrons les bases de la programmation en PHP, un langage permettant de réaliser un site web dynamique et de dialoguer avec une base de données. En particulier :</p>\r\n<ul class=\"list-group list-group-flush\">\r\n<li class=\"list-group-item\">Savoir installer un environnement de travail adapté (éditeur de texte, serveur local, affichage des erreurs, etc)</li>\r\n<li class=\"list-group-item\">Maîtriser les bases du langage PHP (variables, fonctions, boucles, tableaux, etc)</li>\r\n<li class=\"list-group-item\">Savoir transmettre des informations de page en page</li>\r\n<li class=\"list-group-item\">Connaître les variables superglobales importantes (sessions, cookies, etc)</li>\r\n<li class=\"list-group-item\">Savoir lire et écrire des informations dans une base de données</li>\r\n</ul>', '10h', '	\r\n/assets/images/formations/php.png', 1),
(2, 1, 'CSS', 'css', 'Maîtrisez l\'aspect, le comportement et les effets de vos projets', '<p>CSS (Cascading Style Sheets) est un langage de feuilles de style utilisé pour décrire la présentation d\'un document écrit en HTML ou XML. Il est utilisé pour ajouter des styles visuels tels que la couleur, la police, la taille et la disposition des éléments HTML, ainsi que pour créer des mises en page de page web complexes. CSS utilise des sélecteurs pour cibler des éléments HTML spécifiques et des règles de style pour définir l\'apparence de ces éléments.</p>', '<p class=\"card-text\">Un langage qui permettra aux étudiants de maîtriser les bases de CSS et de créer des designs de pages web élégants et performants.</p> <ul class=\"list-group list-group-flush\"> 	<li class=\"list-group-item\">Maîtriser les concepts de base : Un cours de langage CSS devrait aider les étudiants à comprendre les concepts de base tels que les sélecteurs, les propriétés et les valeurs.</li> 	<li class=\"list-group-item\">Connaître les meilleures pratiques : Les étudiants devraient apprendre les meilleures pratiques en matière de structure de feuilles de style, de nommage de classes et d\'organisation de fichiers CSS.</li> 	<li class=\"list-group-item\">Créer des mises en page responsives : Les étudiants devraient être capables de créer des mises en page responsives qui s\'adaptent aux différents appareils et tailles d\'écran.</li> 	<li class=\"list-group-item\">Appliquer des animations et des transitions : Les étudiants devraient être capables d\'appliquer des animations et des transitions CSS pour ajouter des effets visuels à leurs pages web.</li> 	<li class=\"list-group-item\">Optimiser les performances : Les étudiants devraient apprendre comment optimiser les performances de leurs feuilles de style CSS en utilisant des techniques telles que la compression, la minification et la mise en cache.</li> </ul>', '4h', '/assets/images/formations/css.png', 2),
(3, 1, 'Javascript', 'javascript', 'Apportez des fonctionnalités dynamiques aux sites web.', '<p>JavaScript est un langage de programmation populaire utilisé pour créer des pages web interactives et dynamiques.</p>\r\n<p>Il est principalement utilisé en conjonction avec HTML et CSS pour créer des effets visuels, des animations, des interactions avec les utilisateurs, et pour rendre les pages web plus dynamiques.</p>\r\n<p>JavaScript est un langage de script côté client, ce qui signifie qu\'il est exécuté dans le navigateur Web de l\'utilisateur plutôt que sur un serveur distant.</p>\r\n<p>Les avantages de l\'utilisation de JavaScript sont nombreux.</p>\r\n<p>Il permet d\'ajouter une interactivité et une dynamique à une page web, de valider les formulaires, de créer des animations, de charger des données dynamiques à partir de serveurs et de modifier le contenu de la page sans avoir besoin de recharger la page entière.</p>\r\n<p>Il est principalement utilisé en conjonction avec HTML et CSS pour créer des effets visuels, des animations, des interactions avec les utilisateurs, et pour rendre les pages web plus dynamiques.</p>\r\n<p>JavaScript est un langage de script côté client, ce qui signifie qu\'il est exécuté dans le navigateur Web de l\'utilisateur plutôt que sur un serveur distant.</p>\r\n', '<p class=\"card-text\">Un langage qui permettra aux étudiants de maîtriser les bases de CSS et de créer des designs de pages web élégants et performants.</p><ul class=\"list-group list-group-flush\"><li class=\"list-group-item\">Comprendre les bases de la programmation JavaScript : Un cours de langage JavaScript devrait aider les apprenants à comprendre les fondamentaux de la programmation JavaScript, y compris les types de données, les variables, les fonctions, les boucles et les structures de contrôle.</li><li class=\"list-group-item\">Savoir utiliser les API et les bibliothèques JavaScript : JavaScript est utilisé pour créer des interactions dynamiques dans les sites web et les applications, ainsi que pour accéder aux API et aux bibliothèques JavaScript existantes. Les apprenants devraient donc être capables d\'utiliser des API telles que l\'API DOM (Document Object Model) pour manipuler les éléments d\'une page web et des bibliothèques telles que jQuery pour simplifier la création de code. </li><li class=\"list-group-item\">Connaître les concepts avancés de JavaScript : Les apprenants devraient être initiés aux concepts avancés de JavaScript, tels que la programmation orientée objet, les événements, les promises, les closures et les templates.</li><li class=\"list-group-item\">Apprendre à déboguer le code JavaScript : Les apprenants devraient être en mesure de déboguer le code JavaScript à l\'aide d\'outils de développement tels que les outils de débogage intégrés aux navigateurs web et des outils externes tels que Node.js. </li></ul>', '8h', '/assets/images/formations/javascript.png', 3);

-- --------------------------------------------------------

--
-- Structure de la table `formations_etudiant`
--

DROP TABLE IF EXISTS `formations_etudiant`;
CREATE TABLE IF NOT EXISTS `formations_etudiant` (
  `Id_FA` int(10) NOT NULL AUTO_INCREMENT,
  `Id_Etudiant` int(10) NOT NULL,
  `Id_Formation` int(10) NOT NULL,
  `Date_Inscription` date NOT NULL,
  PRIMARY KEY (`Id_FA`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formations_etudiant`
--

INSERT INTO `formations_etudiant` (`Id_FA`, `Id_Etudiant`, `Id_Formation`, `Date_Inscription`) VALUES
(1, 1, 1, '2023-03-23');

-- --------------------------------------------------------

--
-- Structure de la table `formation_modules`
--

DROP TABLE IF EXISTS `formation_modules`;
CREATE TABLE IF NOT EXISTS `formation_modules` (
  `Id_Module` int(10) NOT NULL AUTO_INCREMENT,
  `Id_Formation` int(10) NOT NULL,
  `Id_Niveau` int(10) NOT NULL,
  `Titre` varchar(150) NOT NULL,
  PRIMARY KEY (`Id_Module`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formation_modules`
--

INSERT INTO `formation_modules` (`Id_Module`, `Id_Formation`, `Id_Niveau`, `Titre`) VALUES
(1, 1, 1, 'Présentation de PHP'),
(2, 1, 1, 'Installer PHP sur MacOS'),
(3, 1, 1, 'Installer PHP sur Windows'),
(4, 1, 1, 'Installer PHP sur Linux'),
(5, 1, 1, 'Les variables'),
(6, 1, 1, 'Les tableaux'),
(7, 1, 1, 'Les conditions'),
(8, 1, 1, 'Les boucles'),
(9, 1, 1, 'Les fonctions'),
(10, 1, 1, 'Les fonctions utilisateurs'),
(11, 1, 1, 'Require et Include'),
(12, 1, 1, 'PHP et HTML'),
(13, 1, 1, 'Traitement des formulaires'),
(14, 1, 1, 'Les dates'),
(15, 1, 1, 'Lecture de fichiers'),
(16, 1, 1, 'Écriture de fichiers'),
(17, 1, 1, 'Les Cookies'),
(18, 1, 1, 'La session'),
(19, 1, 2, 'Chiffrer les mots de passe'),
(20, 1, 2, 'L\'objet DateTime'),
(21, 1, 2, 'Les class'),
(22, 1, 2, 'Méthodes et propriétés Statiques'),
(23, 1, 2, 'L\'héritage'),
(24, 1, 3, 'Utiliser une API'),
(25, 1, 3, 'Les Exceptions'),
(26, 1, 3, 'PHPDoc - Commenter son code'),
(27, 1, 3, 'PDO'),
(28, 1, 3, 'Les espaces de noms'),
(29, 1, 3, 'L\'autoloader'),
(30, 1, 3, 'Utiliser des librairies tierces'),
(31, 1, 3, 'Les fonctions anonymes - Closure'),
(32, 3, 1, 'Présentation de JS'),
(33, 3, 1, 'Les variables'),
(34, 3, 1, 'Les conditions'),
(35, 3, 1, 'La portée des variables'),
(36, 3, 1, 'Les boucles'),
(37, 3, 1, 'Les fonctions'),
(38, 3, 1, 'Les classes'),
(39, 3, 1, 'es erreurs'),
(40, 3, 2, 'Les fonctions usuelles'),
(41, 3, 2, 'Le sucre syntaxique'),
(42, 3, 2, 'Promise'),
(43, 3, 2, 'Appel HTTP avec fetch()'),
(44, 3, 2, 'Les modules'),
(45, 3, 2, 'JSDoc - Commenter son code'),
(46, 3, 2, 'L\'objet Date'),
(47, 3, 2, 'JavaScript côté navigateur'),
(48, 3, 2, 'Les écouteurs d\'évènements'),
(49, 3, 2, 'Les templates'),
(50, 3, 3, 'Évènements personnalisés'),
(51, 3, 3, 'Manipuler les cookies'),
(52, 3, 3, 'Inspecter son code'),
(53, 3, 3, 'Fonctions usuelles du DOM'),
(54, 3, 3, 'Local Storage'),
(55, 3, 3, 'JavaScript côté serveur'),
(56, 3, 3, 'Installer NodeJS sur Windows'),
(57, 3, 3, 'Lire et écrire des fichiers'),
(58, 2, 1, 'Présentation de CSS'),
(59, 2, 1, 'Les sélecteurs'),
(60, 2, 1, 'Le modèle de boîte'),
(61, 2, 1, 'Police et textes'),
(62, 2, 1, 'Les formats de couleurs'),
(63, 2, 1, 'Les unités de mesures'),
(64, 2, 2, 'Le positionnement'),
(65, 2, 2, 'Les éléments flottants'),
(66, 2, 2, 'La propriété background'),
(67, 2, 2, 'Le box-sizing'),
(68, 2, 2, 'La spécificité des sélecteurs'),
(69, 2, 2, 'La compatibilité des navigateurs'),
(70, 2, 2, 'Polices personnalisées'),
(71, 2, 2, 'Pseudo-éléments'),
(72, 2, 2, 'Transform'),
(73, 2, 2, 'Animation et Transition'),
(74, 2, 2, 'Media query et le Responsive'),
(75, 2, 3, 'Les frameworks CSS'),
(76, 2, 3, 'Reset et normalize'),
(77, 2, 3, 'Les variables CSS'),
(78, 2, 3, 'Les préprocesseurs CSS');

-- --------------------------------------------------------

--
-- Structure de la table `formation_niveaux`
--

DROP TABLE IF EXISTS `formation_niveaux`;
CREATE TABLE IF NOT EXISTS `formation_niveaux` (
  `Id_Niveau` int(10) NOT NULL AUTO_INCREMENT,
  `Niveau` int(1) NOT NULL,
  `Niveau_Label` varchar(50) NOT NULL,
  PRIMARY KEY (`Id_Niveau`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formation_niveaux`
--

INSERT INTO `formation_niveaux` (`Id_Niveau`, `Niveau`, `Niveau_Label`) VALUES
(1, 1, 'Niveau 1'),
(2, 2, 'Niveau 2'),
(3, 3, 'Niveau 3');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
