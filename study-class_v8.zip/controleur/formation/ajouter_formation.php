<?php
session_start();
include '../../modele/cnx.php';
include '../img.php';

if(isset($_SESSION['login_admin']) && $_SESSION['login_admin']===true){

    if($_SERVER['REQUEST_METHOD'] === 'POST'){

        $titre = ($_POST['titre']);
        $description = ($_POST['description']);
        $ticket = ($_POST['ticket']);
        $duree = ($_POST['duree']);
        $synthese =  ($_POST['synthese']);
        $Id_Formateur= ($_POST['formateur_id']);
        $Active = 1;

        // Validation des données
        $errors = [];

        if(empty($titre)){
            $errors[] = "Le champ titre est obligatoire.";
        }
        if(empty($description)){
            $errors[] = "Le champ description est obligatoire.";
        }
        if(empty($ticket)){
            $errors[] = "Le champ ticket est obligatoire.";
        }
        if(empty($duree)){
            $errors[] = "Le champ durée est obligatoire.";
        }
        if(empty($synthese)){
            $errors[] = "Le champ synthese est obligatoire.";
        }

        // Si pas d'erreurs, on insère la formation
        if(empty($errors)){

            // Enregistrement de l'image
            $resultat = insertion_image("formations");

            // Vérification des erreurs retournées par la fonction
            if (!empty($resultat)) {
                foreach ($resultat as $erreur) {
                    echo $erreur;
                }
            }
            

            // Insertion de la formation dans la base de données
            $query = mysqli_prepare($db, "INSERT INTO formations (Active, Formation, SEO, Titre , Synthese, Descriptif, Duration, Id_Formateur, img) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($query, "sssssssss", $Active, $ticket, $ticket, $titre, $synthese, $description, $duree, $Id_Formateur, $resultat['img']);
// 
// $ticket = $_POST['ticket'];
// $titre = $_POST['titre'];
// $synthese = $_POST['synthese'];
// $description = $_POST['description'];
// $duree = $_POST['duree'];
// $Id_Formateur = $_SESSION['user']['id'];

    if (mysqli_stmt_execute($query)) {
        header('Location: ../../vue/index.php');
        exit;
    } else {
    $errors[] = "Erreur lors de l'ajout de la formation.";
}

        }
    }
}
// print_r($errors);
?>



