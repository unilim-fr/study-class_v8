<?php
session_start();
include '../../modele/cnx.php';
include '../img.php';

if(isset($_SESSION['login_admin']) && $_SESSION['login_admin'] === true){
    if(isset($_GET['id_formation'])) {
    $formationId = $_GET['id_formation'];
    $formationName = $_POST['formationName'];
    $formationDuration = $_POST['formationDuration'];
    $formationTitle=$_POST['formationTitle'];
    $syntheseFormation = $_POST['syntheseFormation'];
    $descriptifFormation = $_POST['descriptifFormation'];
    $Id_Formateur= ($_POST['formateur_id']);
    $errors = [];

    if(empty($formationName)){
        $errors[] = "Le champ Nom de la formation est obligatoire.";
    }
    if(empty($formationDuration)){
        $errors[] = "Le champ Durée de la formation est obligatoire.";
    }
    if(empty($formationTitle)){
        $errors[] = "Le champ durée est obligatoire.";
    }
    if(empty($descriptifFormation)){
        $errors[] = "Le champ descriptif est obligatoire.";
    }
    if(empty($syntheseFormation)){
        $errors[] = "Le champ synthese est obligatoire.";
    }

    // vérifier si un fichier a été téléchargé
    if(empty($errors)){
        $resultat = insertion_image("formations");
        $imgDestination=$resultat['img'];
        // Vérification des erreurs retournées par la fonction
        if (!empty($resultat)) {
            foreach ($resultat as $erreur) {
                echo $erreur;
            }
        }
    } else {
        $imgDestination = $_POST['imgPath'];
    }
    // Mise à jour des données de la formation dans la base de données
    $sql = "UPDATE formations SET Formation = '$formationName', Titre = '$formationTitle',Synthese = '$syntheseFormation', Descriptif = '$descriptifFormation',Duration = '$formationDuration', img = '$imgDestination', Id_Formateur = '$Id_Formateur' WHERE Id_Formation = $formationId";
    $result = mysqli_query($db, $sql);

    if ($result) {
        // Redirection vers la page d'accueil si la mise à jour a réussi
        header("Location: ../../vue/index.php");
        exit();
    } else {
        // Affichage d'un message d'erreur si la mise à jour a échoué
        echo "<script>alert('La mise à jour a échoué. Veuillez réessayer.');</script>";
        exit();
    }
}}
?>