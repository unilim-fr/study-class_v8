<?php
session_start();
include '../../modele/cnx.php';

if (isset($_GET['idformation']) && isset($_SESSION['login_admin']) && $_SESSION['login_admin'] === true) {

    $id_formation = $_GET['idformation'];

    if ($_GET['supp'] == "formation") {
        // Suppression de la formation dans la table "formation"
        $stmt = mysqli_prepare($db, "DELETE FROM formations WHERE Id_Formation = ?");
        mysqli_stmt_bind_param($stmt, "i", $id_formation);
        mysqli_stmt_execute($stmt);
    }

    if($_GET['supp']=='formateur'){
        $stmt = mysqli_prepare($db, "DELETE FROM formateurs WHERE Id_Formateur = ?");
        mysqli_stmt_bind_param($stmt, "i", $id_formation);
        mysqli_stmt_execute($stmt);
    }


    // Redirection vers la page d'accueil
    header('Location: ../../vue/index.php');
    exit;
}
?>