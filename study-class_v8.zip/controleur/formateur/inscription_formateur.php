<?php
session_start();
include '../../modele/cnx.php';
include '../img.php';
if(isset($_SESSION['login_admin'])&& $_SESSION['login_admin']===true){

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $Portfolio=$_POST['portfolio'];
        $email = $_POST['email'];
        $profil = $_POST['profil'];
        $presentation = $_POST['presentation'];
        $mot_de_passe = $_POST['mot-de-passe'];
        $password_verif= $_POST['password_confirmation'];
        $active= '1' ;
        
        if(strlen($mot_de_passe) != strlen($password_verif) && $mot_de_passe != $password_verif){  
            echo '<script>alert("vérifier le mot de passe")</script>';
            exit;
        }else{
            // PASSWORD CRYPTAGE
            $password_hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);
        }
        $errors = [];

        if(empty($nom)){
            $errors[] = "Le champ nom est obligatoire.";
        }
        if(empty($prenom)){
            $errors[] = "Le champ prenom est obligatoire.";
        }
        if(empty($email)){
            $errors[] = "Le champ email est obligatoire.";
        }
        if(empty($profil)){
            $errors[] = "Le champ profil est obligatoire.";
        }
        
        if(empty($presentation)){
            $errors[] = "Le champ presentation est obligatoire.";
        }
        if(empty($mot_de_passe)){
            $errors[] = "Le champ mot_de_passe est obligatoire.";
        }

        if(empty($errors)){
            $Formateur= $prenom .' '. $nom;
            // Appel de la fonction insertion_image et stockage de sa valeur de retour dans une variable $resultat
            $resultat = insertion_image("formateurs");
            // Insertion de la formation dans la base de données
            if($profil == "formateur"){
                $query = $db->prepare('INSERT INTO formateurs (Active, Formateur, Public_Email, Photo, Presentation, Portfolio, User, Pass) VALUES(?, ?, ?, ?, ?, ?, ?, ?)');
                $query->bind_param('ssssssss',$active, $Formateur, $email,  $resultat['img'], $presentation, $Portfolio, $prenom, $password_hash);
                $result = $query->execute();
            }
            if($profil == "administrateur"){
                $query = $db->prepare('INSERT INTO admin (nom_admin, prénom_admin, email_admin, pass_admin) VALUES(?, ?, ?, ?)');
                $query->bind_param('ssss', $nom, $prenom, $email, $password_hash);
                $result = $query->execute();
            }
            if($result){
                header('Location: ../../vue/index.php');
                exit;
            } else {
                $errors[] = "Erreur lors de l'ajout de la formateur.";
            }
            
        }
    }
}


?>
<?php if(isset($errors) && !empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach($errors as $error): ?>
                <p><?php echo $error;?></p>
            <?php endforeach; ?>
        </div>
<?php endif; ?>
