<?php
session_start();
include '../../modele/cnx.php';
include '../img.php';
print_r($_POST);
if(isset($_POST['modif_formateur']) && isset($_SESSION['login_admin']) && $_SESSION['login_admin']===true) {
    // récupérer les données du formulaire
    $formateurId = $_GET['id'];
    $Formateur = $_POST['nomFormateur'];
    $Email=$_POST['email'];
    $presentation = $_POST['presentationFormateur'];
    $portfolio= $_POST['portfolio'];
    $errors = [];
    if(empty($Formateur)){
        $errors[] = "Le champ nom et prénom sont obligatoire.";
    }
    if(empty($presentation)){
        $errors[] = "Le champ présentation est obligatoire.";
    }
    if(empty($portfolio)){
        $errors[] = "Le champ portfolio est obligatoire.";
    }
    if(empty($Email)){
        $errors[] = "Le champ email est obligatoire.";
    }

    // vérifier si un fichier a été téléchargé
    if(empty($errors)){
        $resultat = insertion_image("formateurs");
        $imgDestination=$resultat['img'];
        // Vérification des erreurs retournées par la fonction
        if (!empty($resultat)) {
            foreach ($resultat as $erreur) {
                echo $erreur .'<br>';
            }
        }
    }

    // Mise à jour des données de la formation dans la base de données
    $sql = "UPDATE formateurs SET Formateur = '$Formateur', Public_Email = '$Email', Photo = '$imgDestination', Presentation = '$presentation' WHERE Id_Formateur = $formateurId";
    $result = mysqli_query($db, $sql);

    if ($result) {
        // Redirection vers la page d'accueil si la mise à jour a réussi
        header("Location: ../../vue/index.php");
        exit();
    } else {
        // Affichage d'un message d'erreur si la mise à jour a échoué
        echo "<script>alert('La mise à jour a échoué. Veuillez réessayer.');</script>";
        exit();
    }
}
?>
