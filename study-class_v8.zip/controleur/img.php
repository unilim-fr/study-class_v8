<?php
	function insertion_image($chemain){
		$resultat = array();
		if(isset($_FILES['img']) && $_FILES['img']['error'] === 0){
			$allowedTypes = ['image/png', 'image/jpeg', 'image/gif'];
			$fileType = $_FILES['img']['type'];
			if(in_array($fileType, $allowedTypes)){
				$fileName = $_FILES['img']['name'];
				$fileTmpName = $_FILES['img']['tmp_name'];
				$fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
				$newFileName = uniqid() . '.' . $fileExtension;
	
				$fileSize = $_FILES['img']['size'];
				$fileError = $_FILES['img']['error'];
				$fileTmpName = $_FILES['img']['tmp_name'];
				$fileType = $_FILES['img']['type'];
				$fileName = $_FILES['img']['name'];
				$fileExt = explode('.', $fileName);
				$fileActualExt = strtolower(end($fileExt));
				$allowed = array('jpg', 'jpeg', 'png');
	
				if(in_array($fileActualExt, $allowed)){
					if($fileError === 0){
						if($fileSize < 5000000){
							$newFileName = uniqid('', true) . "." . $fileActualExt;
							if(move_uploaded_file($fileTmpName, "../../vue/assets/images/".$chemain."/" . $newFileName)){
								$resultat['img'] = "/assets/images/".$chemain."/" . $newFileName;
							} else {
								$resultat['errors'][] = "Erreur lors de l'enregistrement de l'image.";
							}
						} else {
							$resultat['errors'][] = "Le fichier est trop volumineux. (max. 5 Mo)";
						}
					} else {
						$resultat['errors'][] = "Erreur lors du téléchargement de l'image.";
					}
				} else {
					$resultat['errors'][] = "Seuls les fichiers JPG, JPEG et PNG sont autorisés.";
				}
			} else {
				$resultat['errors'][] = "Format d'image non autorisé.";
			}
		} else {
			$resultat['errors'][] = "Aucun fichier image n'a été envoyé.";
		}
		return $resultat;
	}
?>