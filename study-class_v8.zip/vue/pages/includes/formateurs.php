<?php
echo '
<section id="formateurs">
	<div class="container py-5 mt-4">
		<div class="row d-flex justify-content-center">
			<div class="col-md-10 col-xl-8 text-center">
				<h3>Nos formateurs</h3>
				<p class="mb-4 pb-2 mb-md-5 pb-md-0">
				Les qualités de nos formateurs qui maitrîses les outils et méthodes d\'apprentissage.
				</p>
			</div>
		</div>

		<div class="row text-center">';
      	if(isset ($_SESSION['login_admin'])&& $_SESSION['login_admin']===true){
		echo'
		<div class="col-md-4 mb-0">
			<div class="card" >
			<div class="card-body py-4 mt-2">
			<div id="form-container">
			<h2>Ajouter un formateur</h2>
				<form action="../controleur/formateur/inscription_formateur.php" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label for="nom">Nom :</label>
					<input type="text" class="form-control" id="nom" name="nom">
				</div>
				<div class="form-group">
					<label for="prenom">Prénom :</label>
					<input type="text" class="form-control" id="prenom" name="prenom">
				</div>
				<div class="form-group">
					<label for="profil">Profil :</label>
					<select class="form-control" id="profil" name="profil">
					<option value="formateur">Formateur</option>
					<option value="administrateur">Administrateur</option>
					</select>
				</div>
				<div class="form-group">
					<label for="presentation">Présentation :</label>
					<textarea class="form-control" id="presentation" name="presentation"></textarea>
				</div>
				<div class="form-group">
					<label for="email">Email :</label>
					<input type="email" class="form-control" id="email_formateur" name="email">
				</div>
				<div class="form-group">
					<label for="mot-de-passe">Mot de passe :</label>
					<input type="password" class="form-control" id="mot-de-passe"  name="mot-de-passe">
				</div>
				<div class="form-group">
					<label for="mot-de-passe">Confirmation mot de passe :</label>
					<input type="password" class="form-control" id="password_confirmation" name="password_confirmation" >
				</div>
				<div class="form-group">
					<label for="portfolio">Portfolio :</label>
					<input type="text" class="form-control" id="portfolio" name="portfolio" value="">
				</div>
				<div class="form-group">
					<label for="image">Image :</label>
					<input type="file" class="form-control-file" id="image_formateur" name="img" accept="image/*" required>
				</div>
				<button type="submit" class="btn btn-primary">Ajouter</button>
				</form>
				</div></div></div></div>';
			}
			foreach($Liste_Formateurs AS $Formateur) {
				echo '
				<div class="col-md-4 mb-4 mb-md-0 formation">';
			if(isset($_SESSION['login_admin']) && $_SESSION['login_admin']===true){
			echo '
				<button type="button" class="btn btn-danger delete-formateur supp" data-id="'. $Formateur['Id_Formateur'].'">x</button>
				<button type="button" class="btn btn-primary modif modif-formateur" data-id="'. $Formateur['Id_Formateur'].'"><i class="fas fa-edit ml-2"></i></button>';
				}
					echo'<div class="card">
						<div class="card-body py-4 mt-2" id="formateur-info-'.$Formateur['Id_Formateur'].'">
							<div class="d-flex justify-content-center mb-4" >
								<img src="'.$Base_URL.$Formateur['Photo'].'" alt="'.$Formateur['Formateur'].'" title="'.$Formateur['Formateur'].'" class="rounded-circle shadow-1-strong" width="100" height="100">
							</div>

							<h5 class="f-w">'.$Formateur['Formateur'].'</h5>
							<h6 class="fw-bold mb-4">Développement web</h6>
							<hr>
							'.$Formateur['Presentation'].'
							<p><a href="mailto:'.$Formateur['Public_Email'].'"><i class="fa fa-envelope ms-2"></i> '.$Formateur['Public_Email'].'</a></p>
							
							<div class="trainer mt-4">
								<div class="trainer-profile text-align-center">
									<a href="'.$Formateur['Portfolio'].'" target="_blank"><button type="submit" class="j-btn">Visiter mon site</button></a>
								</div>
								<br><br>
							</div>

						</div>
						<form class="card-body py-4 mt-2 formateur-form" id="formateur-form-'.$Formateur['Id_Formateur'].'" style="display:none;"action="../controleur/formateur/modifier_formateur.php?id='.$Formateur['Id_Formateur'].'" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="nomFormateur">Nom et Prénom :</label>
								<input type="text" class="form-control"  name="nomFormateur" value="'.$Formateur['Formateur'].'">
							</div>
							<div class="form-group">
								<label for="presentationFormateur">Présentation :</label>
								<textarea class="form-control"  name="presentationFormateur" >'.$Formateur['Presentation'].'</textarea>
							</div>
							<div class="form-group">
								<label for="email">Email :</label>
								<input type="email" class="form-control" name="email" value="'.$Formateur['Public_Email'].'">
							</div>
							<div class="form-group">
								<label for="portfolio">Portfolio :</label>
								<input type="text" class="form-control"  name="portfolio" value="'.$Formateur['Portfolio'].'">
							</div>
							<div class="form-group">
								<label for="image">Image :</label>
								<input type="file" class="form-control-file"  name="img" accept="image/*">
							</div>
							
							<button type="submit" class="btn btn-primary" name="modif_formateur">Enregistrer</button>
							<button type="button" class="btn btn-secondary annuler" data-dismiss="modal" href="./">Annuler</button>
							</form>
						</div>
					</div>';
			}

		echo '
		</div>
	</div>
</section>';
?>
