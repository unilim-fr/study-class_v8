<?php

echo '
<div class="breadcrumbs">
	<div class="container">
		<h1>Formation '.$Formation['Formation'].'</h1>
	</div>
</div>

<section id="course-details" class="course-details">
	<div class="container mt-5">
		<div class="row">
			<div class="col-lg-8">
				<img src="'.$Base_URL.'/assets/images/formations/'.$Formation['SEO'].'-discovery.jpg" class="img-fluid mb-3" alt="PHP">
				<div class="card p-2 mb-2">
					<div class="card-body">
						<h5 class="mb-3">Présentation</h5>

						'.$Formation['Synthese'].'

						<h5 class="mb-3">Objectifs</h5>

						'.$Formation['Descriptif'].'

					</div>
				</div>
			</div> 
			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<div class="row justify-content-center">
							<div class="col-md-12 text-center">
								<h5 class="card-title">Responsable de la formation</h5>
							</div>
							<div class="col-md-4">
								<img src="'.$Base_URL.$Formation['Photo'].'" class="img-fluid rounded-circle" alt="image">
							</div>
							<div class="col-md-6">
								<div class="ml-3">
									<p>'.$Formation['Formateur'].'</p>
									<p><a href="mailto:'.$Formation['Public_Email'].'">'.$Formation['Public_Email'].'</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<br>
				<div class="d-flex justify-content-between align-items-center">
					<div class="card">
						<div class="card-body">
							<div class="col-md-12 text-center">
								<h5 class="card-title">Modalités de la formation</h5>
							</div>
							<ul class="list-group list-group-flush">
								<li class="list-group-item">Prix de la formation : Gratuit</li>
								<li class="list-group-item">Places libres : 30 places</li>
								<li class="list-group-item">Horaires : 17h00 - 19h00</li>
								<li class="list-group-item">Durée de la formation : '.$Formation['Duration'].'</li>
							</ul>
							<hr>
							<div class="text-center">
								<p>Merci de vous connecter à votre espace pour vous inscrire.</p>
								<a href="'.$Base_URL.'/mon-espace"><button type="button" class="j-btn" id="espace-btn">Mon espace</button></a>
							</div>
						</div>
					</div>
				</div>
			</div> 
		</div>
	</div>
</section>';
?>
