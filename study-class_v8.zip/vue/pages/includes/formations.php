<?php
include "../modele/cnx.php";
echo '
<div class="divider" id="formations"></div>

<section id="formation" class="formation">
	<div class="container">
		<div class="row">';
		//
		if(isset($_SESSION['login_admin']) && $_SESSION['login_admin']===true){
		echo'
		<div class="col-lg-4 col-md-6 d-flex align-items-stretch formation">
		  <div class="course-item">
			<div class="container">
			  <h2>Ajouter une formation</h2>
			  <form action="../controleur/formation/ajouter_formation.php" method="POST" enctype="multipart/form-data">
				<div class="form-group">
				  <label for="titre">Titre:</label>
				  <input type="text" class="form-control" id="titre" name="titre" required>
				</div>
				<div class="form-group">
				  <label for="ticket">Ticket:</label>
				  <input type="text" class="form-control" id="ticket" name="ticket" required>
				</div>
				<div class="form-group">
				  <label for="durée">Durée:</label>
				  <input type="text" class="form-control" id="durée" name="duree" required>
				</div>
				<input type="hidden" name="id_formation" value="'.'">
				<div class="form-group">
				  <label for="formateur_id">Formateur :</label>
				  <select class="form-control" id="formateur_id" name="formateur_id">';
					
				  $sql = "SELECT * FROM formateurs";
				  $result = mysqli_query($db, $sql);
			  
				  // Afficher chaque formateur dans le menu déroulant
				  while ($formateur = mysqli_fetch_assoc($result)) {
					echo '<option value="' . $formateur['Id_Formateur'] . '">' . $formateur['Formateur'] .'</option>';
				  }
				  echo '</select>
				  </div>
				<div class="form-group">
				  <label for="synthese">Synthese:</label>
				  <textarea class="form-control" id="synthese" name="synthese" required></textarea>
				</div>
				<div class="form-group">
				  <label for="description">Description:</label>
				  <textarea class="form-control" id="description" name="description" required></textarea>
				</div>
				<div class="form-group">
				  <label for="image">Image:</label>
				  <input type="file" class="form-control-file" id="image" name="img" accept="image/*" required>
				</div>
				<button type="submit" class="btn btn-primary">Ajouter</button>
			  </form>
			</div>
		  </div>
		</div> ';
		}
		//
		echo'
		<div class="col-md-6 offset-md-3">
        <form action="" method="get" class="form-inline my-4 my-lg-0">
        	<div class="d-flex align-items-end mb-4">
            <input class="form-control mr-sm-2" type="text" placeholder="Recherche" aria-label="Recherche" name="search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Rechercher</button>
          </div>
        </form>
    	</div>';

		if(isset($_GET['search']) && !empty($_GET['search'])){
			$search = $_GET['search'];
			$requete = $db->query("SELECT * FROM formations WHERE SEO LIKE '%$search%'");
		
			if ($requete->num_rows > 0) {
				// Il y a des résultats de recherche
				while ($Formation = $requete->fetch_assoc()) {
					// Afficher les détails de la formation
					echo '<div class="col-lg-4 col-md-6 d-flex align-items-stretch">
						<div class="item">
							<img src="'.$Base_URL.$Formation['img'].'" class="img-fluid" alt="'.$Formation['Formation'].'">
							<div class="content">
								<div class="d-flex justify-content-between align-items-center mb-3">
									<h4>Formation '.$Formation['Formation'].'</h4>
									<p class="duration">'.$Formation['Duration'].'</p>
								</div>
								<h5><a href="#">'.$Formation['Titre'].'</a></h5>
								<div class="next d-flex justify-content-between align-items-center">
									<div class="d-flex align-items-center">
										<a href="'.$Base_URL.'/formation/'.$Formation['SEO'].'.html"><button type="submit" class="btn">Découvrir</button></a>
									</div>
								</div>
							</div>
						</div>
					</div>';
				}
			} else {
				// Aucun résultat de recherche
				echo '<div class="text-center"><p>Aucune formation trouvée</p></div>';
			}
		}else {
			foreach($Liste_Formations AS $Formation) {
				echo '
				<div class="col-lg-4 col-md-6 align-items-stretch formation">';
				
				if(isset($_SESSION['login']) && $_SESSION['login']===true && $_SESSION['login_admin']===true){
					echo'
				<button type="button" class="btn btn-danger delete-formation supp" data-id="'.$Formation['Id_Formation'].'">x</button>
				<button type="button" class="btn btn-primary modif modif-formation" data-id="'.$Formation['Id_Formation'].'"><i class="fas fa-edit ml-2"></i></button>
				
				<form id="formation-form-'.$Formation['Id_Formation'].'" action="../controleur/formation/modif_formation.php?id_formation='.$Formation['Id_Formation'].'" style="display:none; text-align: center;" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label for="formationName">Nom de la formation</label>
						<input type="text" class="form-control"  name="formationName" value="'.$Formation['Formation'].'" required>
					</div>
					<div class="form-group">
						<label for="formationDuration">Durée de la formation</label>
						<input type="text" class="form-control"  name="formationDuration" value="'.$Formation['Duration'].'" required>
					</div>
					<div class="form-group">
						<label for="formationTitle">Titre de la formation</label>
						<input type="text" class="form-control"  name="formationTitle" value="'.$Formation['Titre'].'" required>
					</div>
					<div class="form-group">
						<label for="formateur_id">Formateur :</label>
						<select class="form-control" name="formateur_id">';
							$sql = "SELECT * FROM formateurs";
							$result = mysqli_query($db, $sql);
							// Afficher chaque formateur dans le menu déroulant
							while ($formateur = mysqli_fetch_assoc($result)) {
								echo '<option value="' . $formateur['Id_Formateur'] . '">' . $formateur['Formateur'] .'</option>';
							}
					echo '</select>
					</div>
					<div class="form-group">
						<label for="syntheseFormation">Synthese de la formation</label>
						<textarea type="text" class="form-control"  name="syntheseFormation" required>'.$Formation['Synthese'].'</textarea>
					</div>
					<div class="form-group">
						<label for="descriptifFormation">Descriptif de la formation</label>
						<textarea type="text" class="form-control"  name="descriptifFormation" required>'.$Formation['Descriptif'].'</textarea>
					</div>

					<div class="form-group">
						<label for="formationImage">Image de la formation</label>
						<input type="file" class="form-control-file"  name="img" accept="image/*" required>
					</div>
					<button type="submit" class="btn btn-primary">Enregistrer</button>
	          		<button type="button" class="btn btn-secondary annuler" data-dismiss="modal" href="./">Annuler</button>
				</form>';
				}

				echo'
					<div class="course-item formation_info_'.$Formation['Id_Formation'].'">
						<img class="img-fluid mx-auto d-block" src="'.$Base_URL.$Formation['img'].'" alt="'.$Formation['Formation'].'">
						<div class="course-content">
							<div class="d-flex justify-content-between align-items-center mb-3">
								<h4>Formation '.$Formation['Formation'].'</h4>
								<p class="duration">'.$Formation['Duration'].'</p>
							</div>

							<h5><a href="#">'.$Formation['Titre'].'</a></h5>
							<div class="trainer d-flex justify-content-between align-items-center">
								<div class="trainer-profile d-flex align-items-center">
									<a href="'.$Base_URL.'/formation/'.$Formation['SEO'].'.html"><button type="submit" class="btn">Découvrir</button></a>
								</div>
							</div>
						</div>
					</div>
				</div>';
			}
		}
		echo '
		</div>
	</div> 
</section>';
?>

