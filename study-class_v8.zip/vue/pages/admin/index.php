<?php
IF (!isset($_SESSION['A_Auth_Code']) OR $_SESSION['A_Auth_Code']=="") {
	require("login.php");
}Else {
	require("admin.php");
}
