<?php
$Id_Module_Selected = $_POST['Select_Module'] ?? "";
$Id_Niveau_Selected = $_POST['Select_Niveau'] ?? "";
$Id_Form_Selected	= $_POST['Select_Form'] ?? "";

///
IF (isset($_POST['UP_Formation'])) {
	$Active			= $_POST['Active'];
	$Formation		= $_POST['Formation'];
	$SEO			= SEO($Formation);
	$Titre			= $_POST['Titre'];
	$Synthese		= addslashes($_POST['Synthese']);
	$Descriptif		= addslashes($_POST['Descriptif']);
	$Id_Formateur	= $_POST['Formateur'];
	$Duration		= $_POST['Duration'];

	mysqli_query($db, "
	UPDATE Formations SET 
	Active			= \"$Active\", 
	Formation		= \"$Formation\", 
	SEO				= \"$SEO\", 
	Titre			= \"$Titre\", 
	Synthese		= \"".$Synthese."\", 
	Descriptif		= \"".$Descriptif."\", 
	Id_Formateur	= \"$Id_Formateur\", 
	Duration		= \"$Duration\" 
	WHERE Id_Formation = '$Id_Formation_Selected'");
}

///
$RsFormation = mysqli_query($db, "SELECT * FROM Formations WHERE Id_Formation = '$Id_Formation_Selected'");
$data_Formation = mysqli_fetch_assoc($RsFormation);
	$Active			= $data_Formation['Active'];
	$Formation		= $data_Formation['Formation'];
	$SEO			= $data_Formation['SEO'];
	$Titre			= $data_Formation['Titre'];
	$Synthese		= $data_Formation['Synthese'];
	$Descriptif		= $data_Formation['Descriptif'];
	$Duration		= $data_Formation['Duration'];
	$Id_Formateur	= $data_Formation['Id_Formateur'];

$Tab_Selected = $_POST['Tab'] ?? "Fiche";

echo '
<hr>

<ul class="nav nav-tabs" role="tablist">
	<li class="nav-item" role="presentation">
		<button class="nav-link'; IF ($Tab_Selected=='Fiche') { echo ' active'; } echo '" id="Fiche-tab" data-bs-toggle="tab" data-bs-target="#Fiche" type="button" role="tab" aria-controls="Fiche" aria-selected="'; IF ($Tab_Selected=='Fiche') { echo 'true'; } Else { echo 'false'; } echo '">Fiche</button>
	</li>
	<li class="nav-item" role="presentation">
		<button class="nav-link'; IF ($Tab_Selected=='Programme') { echo ' active'; } echo '" id="Programme-tab" data-bs-toggle="tab" data-bs-target="#Programme" type="button" role="tab" aria-controls="Programme" aria-selected="'; IF ($Tab_Selected=='Programme') { echo 'true'; } Else { echo 'false'; } echo '">Programme</button>
	</li>
	<li class="nav-item" role="presentation">
		<button class="nav-link'; IF ($Tab_Selected=='Evaluations') { echo ' active'; } echo '" id="Evaluations-tab" data-bs-toggle="tab" data-bs-target="#Evaluations" type="button" role="tab" aria-controls="Evaluations" aria-selected="'; IF ($Tab_Selected=='Evaluations') { echo 'true'; } Else { echo 'false'; } echo '">Evaluations</button>
	</li>
</ul>
	
<div class="tab-content mt-4 mb-4">
	<div class="tab-pane fade'; IF ($Tab_Selected=='Fiche') { echo ' show active'; } echo '" id="Fiche" role="tabpanel" aria-labelledby="Fiche-tab">';
		require("formation_fiche.php");
	echo '
	</div>
	<div class="tab-pane fade'; IF ($Tab_Selected=='Programme') { echo ' show active'; } echo '" id="Programme" role="tabpanel" aria-labelledby="Programme-tab">';

		require("formation_modules.php");

	echo '
	</div>
	<div class="tab-pane fade'; IF ($Tab_Selected=='Evaluations') { echo ' show active'; } echo '" id="Evaluations" role="tabpanel" aria-labelledby="Evaluations-tab">';
		require("formation_evaluations.php");
	echo '
	</div>
</div>';
?>
