<?php
require("./pages/includes/carousel.php");
require("./pages/includes/presentation.php");
require("./pages/includes/formations.php");
require("./pages/includes/actualites.php");
require("./pages/includes/formateurs.php");
require("./pages/includes/contact.php");
?>
