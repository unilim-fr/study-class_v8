<?php
echo '
<div class="row justify-content-xl-center gy-3 gy-sm-4">';

	$RsModules_Niveaux = mysqli_query($db, "
	SELECT Formation_Modules.Id_Niveau, Niveau_Label FROM 
	Formation_Modules, Formation_Niveaux 
	WHERE Formation_Modules.Id_Niveau = Formation_Niveaux.Id_Niveau 
	AND Id_Formation = '$Id_Formation_Selected' 
	GROUP BY Formation_Modules.Id_Niveau");
	while ($data_Modules_Niveaux = mysqli_fetch_assoc($RsModules_Niveaux)) {
		$Id_Niveau		= $data_Modules_Niveaux['Id_Niveau'];
		$Niveau_Label	= $data_Modules_Niveaux['Niveau_Label'];

		$RsProgression = mysqli_query($db, "
		SELECT 
		Evaluations_Scores.Coefficient,
		Evaluations_Scores.Score,
		Evaluations_Scores.Date_MAJ 
		FROM Evaluations_Forms, Evaluations_Scores 
		WHERE 
		Evaluations_Forms.Id_Form = Evaluations_Scores.Id_Form
		AND Evaluations_Forms.Id_Formation = '$Id_Formation_Selected' 
		AND Evaluations_Forms.Id_Niveau = '$Id_Niveau' 
		AND Evaluations_Scores.Id_Etudiant = '$Id_Etudiant' 
		ORDER BY Evaluations_Scores.Date_MAJ DESC");
		$data_Progression = mysqli_fetch_assoc($RsProgression);
			$Coefficient	= $data_Progression['Coefficient'] ?? 0;
			$Score			= $data_Progression['Score'] ?? 0;
			$Date_MAJ		= $data_Progression['Date_MAJ'] ?? "";

		IF ($Date_MAJ!="") {
			$Date_MAJ = date("d-m-Y à H:i", strtotime($Date_MAJ));
			$Comment = "Dernière évaluation le $Date_MAJ";
		}

		Else {
			$Comment = "En attente d'évaluation.";
		}

		echo '
		<div class="col-lg-4">
			<div class="bg-white rounded shadow-sm p-3 p-md-4 p-xxl-5">
				<h4 class="fw-bold mb-2">'.$Niveau_Label.'</h4>
				<p class="text-secondary fst-italic mb-4">'.$Comment.'</p>
				<div class="progress">
					<div class="progress-bar progress-bar-striped progress-bar-animated" style="width: '.$Score.'%" role="progressbar" aria-label="'.$Niveau_Label.'" aria-valuenow="'.$Score.'" aria-valuemin="0" aria-valuemax="100">'.$Score.'%</div>
				</div>
			</div>
		</div>';
	}

	echo '
</div>';
?>
