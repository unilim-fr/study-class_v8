<?php
IF (!isset($_SESSION['E_Auth_Code']) OR $_SESSION['E_Auth_Code']=="") {
	require("login.php");
}Else {
	require("espace.php");
}
?>
