<?php
$Id_Formation_Selected	= $_POST['Select_Formation'] ?? "";
$Id_Module_Selected		= $_POST['Select_Module'] ?? "";
$Id_Niveau_Selected		= $_POST['Evaluation'] ?? "";

$Espace_Inc = 'dashboard.php';

IF (isset($_POST['Subscribe_Formation']) AND $_POST['Subscribe_Formation']!="") {
	$Subscribe_Formation = $_POST['Subscribe_Formation'] ?? "";
	$Date_Inscription = date('Y-m-d');
	
	mysqli_query($db,"INSERT INTO Formations_Etudiant (`Id_FA`, `Id_Etudiant`, `Id_Formation`, `Date_Inscription`) VALUES (NULL, \"$Id_Etudiant\", \"$Subscribe_Formation\", \"$Date_Inscription\")");
}

IF ($Id_Formation_Selected!='') {
	$Espace_Inc = 'formation.php';
}
?>

<div class="container mt-5">
	<div class="container px-4 py-5" id="espace">
		<h3 class="pb-2 border-bottom">Espace etudiant</h3>
		<div class="row mb-3 mt-4">
			<div class="col-lg-6">
				
				<form action="" method="post">
					<div class="input-group mb-3">
						<select name="Select_Formation" class="form-select" autocomplete="off">
							<option value="">Suivre une formation</option>
							<?php
							$RsMes_Formations = mysqli_query($db, "
							SELECT 
							Formations.Id_Formation AS Id_Formation, 
							Formations.Formation AS Formation, 
							Formations_Etudiant.Date_Inscription AS Date_Inscription 
							FROM Formations_Etudiant, Formations 
							WHERE 
							Formations_Etudiant.Id_Formation = Formations.Id_Formation 
							AND Id_Etudiant = '$Id_Etudiant'");
							while ($data_Mes_Formations = mysqli_fetch_assoc($RsMes_Formations)) {
								$Id_Formation		= $data_Mes_Formations['Id_Formation'];
								$Formation			= $data_Mes_Formations['Formation'];
								$Date_Inscription	= $data_Mes_Formations['Date_Inscription'];
								$Date_Inscription	= date("d-m-Y", strtotime($Date_Inscription));

								echo '
								<option value="'.$Id_Formation.'"'; IF ($Id_Formation==$Id_Formation_Selected) { echo ' selected'; } echo '>'.$Formation.' : inscrit depuis le '.$Date_Inscription.'</option>';
							}
							?>
						</select>
						<button type="submit" class="j-btn" id="espace-btn"><i class="fa fa-check"></i></button>
					</div>
				</form>
	
			</div>
			<div class="col-lg-6">
				<?php
				$RsListe_Formations = mysqli_query($db, "
				SELECT * FROM Formations WHERE Id_Formation NOT IN (
					SELECT 
					Formations.Id_Formation AS Id_Formation 
					FROM Formations_Etudiant, Formations 
					WHERE 
					Formations_Etudiant.Id_Formation = Formations.Id_Formation 
					AND Id_Etudiant = '$Id_Etudiant'
				)
				ORDER BY Formation");
				$Is_Liste_Formations = mysqli_num_rows($RsListe_Formations) ?? 0;

				IF ($Is_Liste_Formations>0) {
					echo '
					<form action="" method="post">
						<div class="input-group mb-3">
							<select name="Subscribe_Formation" class="form-select" autocomplete="off">
								<option value="">M\'inscrire à une nouvelle formation</option>';

								while ($data_Liste_Formations = mysqli_fetch_assoc($RsListe_Formations)) {
									$Id_Formation		= $data_Liste_Formations['Id_Formation'];
									$Formation			= $data_Liste_Formations['Formation'];

									echo '
									<option value="'.$Id_Formation.'">'.$Formation.'</option>';
								}

							echo '
							</select>
							<button type="submit" class="j-btn" id="espace-btn"><i class="fa fa-check"></i></button>
						</div>
					</form>';
				}
				?>
				
			</div>
		</div>
		<div class="mb-3 mt-4">
			<?php require("incs/$Espace_Inc"); ?>
		</div>
	</div>
</div>
