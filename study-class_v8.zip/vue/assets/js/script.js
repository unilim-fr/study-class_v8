$(document).ready(function() {
	$('.nav-scroll').on('click', function() {
		var page = $(this).attr('data-target');
		var speed = 750;
		$('html, body').animate( { scrollTop: $(page).offset().top-100 }, speed ); // Go
		return false;
	});
});

if ($('#Chk_Privacy').length > 0) {
	const Chk_Privacy = document.getElementById('Chk_Privacy');
		
	Chk_Privacy.onclick = function() {
		var send_form_btn = document.getElementById('send_form_btn');
		if(Chk_Privacy.checked===true) {send_form_btn.setAttribute('type', 'submit');}
		else {send_form_btn.setAttribute('type', 'button');}
	}
};

$(".annuler").on('click', function() {
	location.reload();
});
// Ajouter un écouteur d'événements pour chaque bouton de suppression de formation
$('.delete-formation').on('click', function() {
	// Récupérer l'ID de la formation à supprimer
	const formationId = $(this).data('id');
	// Appeler la fonction pour supprimer la formation correspondante
	var lien = "../controleur/formation/supprimer_formation.php";
	var message_formation="supprimer cette formation";
	ordreFormation(formationId , lien , message_formation, 'formation' );
});

$('.delete-formateur').on('click', function() {
	const formationId = $(this).data('id');
	var lien = "../controleur/formation/supprimer_formation.php";
	var message_formation="supprimer ce formateur?";
	ordreFormation(formationId , lien , message_formation,'formateur' );
});


function ordreFormation(idFormation , link , ordre, $supp) {
	if (confirm("Êtes-vous sûr de vouloir "+ ordre + "?")) {
		// envoyer une requête HTTP pour supprimer la formation
		$.ajax({
			url: link + '?idformation=' + idFormation +'&supp='+$supp,
			method: 'GET',
			success: function() {
				// recharger la page pour afficher les changements
				location.reload();
			},
			error: function() {
				alert("La "+ ordre +" a échoué.");
			}
		});
	}
}

	$(".modif-formation").on("click", function() {
		// Récupérer l'id du formateur à partir du bouton cliqué
		var formateurId = $(this).data("id");
		// Cacher la div contenant les informations du formateur
		//$(".formation_info_" + formateurId).hide();
		// Afficher le formulaire correspondant
		$("#formation-form-" + formateurId).show();
		// Changer le style d'affichage du formulaire
		$("#formation-form-" + formateurId).css("display", "block");
	});

	$(".modif-formateur").on("click", function() {
		// Récupérer l'id du formateur à partir du bouton cliqué
		var formateurId = $(this).data("id");
		// Cacher la div contenant les informations du formateur
		$("#formateur-info-" + formateurId).hide();
		// Afficher le formulaire correspondant
		$("#formateur-form-" + formateurId).show();
		// Changer le style d'affichage du formulaire
		$("#formateur-form-" + formateurId).css("display", "block");
	});
