<?php
//	Paramètres de connection
$servername	= "localhost";
$username	= "unilim";/*"unilim";*/
$password	= "uUx3E655JU6w!";//"uUx3E655JU6w!";
$bdd		= "Study_Class";

$db = mysqli_connect($servername, $username, $password, $bdd);
mysqli_set_charset($db,"utf8");
?>
