<?php
$RsFormateurs = mysqli_query($db, "
SELECT 
Id_Formateur, 
Formateur, 
Public_Email,
Photo, 
Presentation, 
Portfolio 
FROM Formateurs 
WHERE Active = '1'
ORDER BY Formateur ");

while ($data_Formateurs = mysqli_fetch_assoc($RsFormateurs)) {
	$Liste_Formateurs[] = $data_Formateurs;
}
?>
