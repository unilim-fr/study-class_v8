<?php
$RsFormations = mysqli_query($db, "SELECT * FROM Formations WHERE Active = '1'");
while ($data_Formations = mysqli_fetch_assoc($RsFormations)) {
	$Liste_Formations[] = $data_Formations;
}
?>
